"""plotter1 controller."""

from controller import Robot, Motor

# 建立 Robot 物件
robot = Robot()

# 取得模擬的時間步長 (time step)
timestep = int(robot.getBasicTimeStep())

# 取得馬達裝置 t1
t1 = robot.getDevice('t2')

# 設定馬達為「速度控制模式」
# position = float('inf') 代表馬達會持續旋轉，而非轉到某個特定位子
t1.setPosition(float('inf'))

# 設定旋轉速度（單位是 rad/s）
# 這裡設定為 0.1 是「慢速旋轉」，可以依需要調整
t1.setVelocity(10)

# 主迴圈：讓模擬持續運行
while robot.step(timestep) != -1:
    # 馬達會持續旋轉，不需要額外指令
    pass

# 模擬結束後的清理（可省略）

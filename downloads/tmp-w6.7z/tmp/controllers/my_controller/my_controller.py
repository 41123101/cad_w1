from controller import Robot, Motor

# create the Robot instance.
robot = Robot()

# get the time step of the current world.
timestep = int(robot.getBasicTimeStep())

# 获取马达t1
t1 = robot.getDevice('t1')  # 获取名称为 't1' 的马达

# 设置马达为速度控制模式
t1.setPosition(float('inf'))  # 设置马达为无限旋转模式
t1.setVelocity(1.0)  # 设置旋转速度，1.0 可以根据需要调节

# Main loop:
# - perform simulation steps until Webots is stopping the controller
while robot.step(timestep) != -1:
    # 在這裡你可以控制t1的速度或執行其他操作
    pass

# Exit cleanup code.
